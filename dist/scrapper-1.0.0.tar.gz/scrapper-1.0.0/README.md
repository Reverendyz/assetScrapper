# assetScrapper

Only an asset Scrapper based on https://statusinvest.com/fundos-imobiliarios/\<TickerToScrape\> (Ex.: hctr11)

## Pre requisites

- ``` pip install requests bs4```
- know about some assets in the brasilian trade market (Only work with ```fundos imobiliarios```)
  
## An explorer of assets

### Steps

1. Just run as-is or add/remove assets from list in main.py
2. Check the [teste.json](teste.json) file for results :)